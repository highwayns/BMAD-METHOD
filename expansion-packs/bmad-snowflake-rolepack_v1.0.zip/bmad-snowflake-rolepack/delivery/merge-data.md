# 数据合并与对账（CSV）
- 主键：database/schema/table + 日期窗口
- 统一日期/数值/口径格式，生成校验报告
