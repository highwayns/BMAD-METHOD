# 打包与归档规则
- 关键节点（Contract/Arch/ELT/DT/Semantic/UDF/Release）执行 *bundle：生成清单、校验哈希、版本快照
- 文档/SQL/脚本/数据分仓；审计日志同行
