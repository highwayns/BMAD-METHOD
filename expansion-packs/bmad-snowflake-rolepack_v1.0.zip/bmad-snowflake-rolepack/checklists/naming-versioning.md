# 命名与版本
- `SFLK_${ORG}_${DOMAIN}_${PROJECT}_${ENV}_${COMP}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；破坏性变更需变更单与回执
