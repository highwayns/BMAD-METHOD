# DoR / DoD（按阶段）
- 合同：口径/SLA/SLO/隐私；DoD：data-contract 发布并获签
- 架构：DB/Schema/DT/权限/仓库；DoD：database-schema-spec + rbac-role-hierarchy 发布
- 实施：ELT/Streaming 可复现；DoD：stage/fileformat + snowpipe + streams/tasks 生效
- 语义层/DT：口径一致、DQ；DoD：DQ 报告全绿
- Snowpark/UDF：模型卡/监控；DoD：model-udf-card 生效
- 发布/运营：CI/CD + 监控；DoD：actions 成功 + 监控生效
