# Orchestration（编排操作手册）

## 节拍
Use Case → Data Contract → Snowflake Arch（DB/Schema/Warehouse/RBAC）→ ELT（Stage/FileFormat/Copy | Snowpipe/Streams/Tasks）→ 动态表/语义层 → Snowpark/UDF → 治理（安全/隐私）→ CI/CD → Observability & FinOps → Ops/Backfill/Postmortem

## 常用命令
- `*agent business-analyst → *create-doc data-contract`
- `*agent snowflake-architect → *create-doc snowflake-architecture`
- `*agent data-engineering-lead-elt → *create-doc stage-and-fileformat-design`
- `*agent ingestion-and-streaming-engineer-snowpipe-streams-tasks → *create-doc snowpipe-design`
- `*agent analytics-engineer-bisql → *create-doc semantic-layer-views`
- `*agent ml-engineer-snowpark → *create-doc model-udf-card`
- `*agent security-and-governance-rbac-policy → *create-doc rbac-role-hierarchy`
- `*agent release-and-change-manager → *create-doc ci-cd-guide`

## 触发器
- Contract Locked：进入 Architecture
- RBAC/Policy Ready：部署 ELT/Streaming
- Semantic DQ Passed：进入 Release
- UDF Ready：批量推理上线
- Monthly Credit Bill：FinOps Review
- Incident Resolved：复盘
