# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| BA/Contract | Architect | Contract Locked | docs/data-contract.md | docs/database-schema-spec.md | 命名/口径一致 |
| Architect | ELT/Streaming | RBAC/Policy Ready | docs/rbac-role-hierarchy.md | docs/stage-and-fileformat-design.md + docs/snowpipe-design.md | 加载与流式跑通 |
| ELT/AE | QA/Release | Semantic DQ Passed | data/dq_rules.csv + 测试报告 | ci-cd/github-actions-snowflake.yml | CI 通过 |
| ML (Snowpark) | Serving/Obs | UDF Ready | docs/model-udf-card.md | snowpark/sp_batch_inference.sql | 端点/任务健康、SLO 告警 |
| FinOps/Obs | Platform | Monthly Credit Bill | data/kpi.csv + data/credit_budgets.csv | 优化建议 | 成本回归目标 |
