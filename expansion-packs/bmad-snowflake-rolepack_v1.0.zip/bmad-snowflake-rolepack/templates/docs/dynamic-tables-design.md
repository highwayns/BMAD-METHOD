# Dynamic Tables 设计
- 物化/刷新策略/依赖图
