# Stage & FileFormat（暂存与文件格式）
- 外部/内部 Stage；文件格式；Copy Into
