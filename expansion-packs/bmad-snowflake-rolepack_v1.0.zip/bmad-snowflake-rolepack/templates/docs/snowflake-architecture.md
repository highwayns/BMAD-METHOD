# Snowflake Architecture（架构）
- 账户/数据库/Schema/仓库/共享/治理
