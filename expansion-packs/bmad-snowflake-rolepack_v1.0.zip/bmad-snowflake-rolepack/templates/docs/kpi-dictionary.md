# KPI Dictionary（指标）
- 延迟/可用性/信用/质量
