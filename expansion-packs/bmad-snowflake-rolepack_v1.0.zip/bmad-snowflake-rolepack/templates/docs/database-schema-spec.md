# Database & Schema Spec（数据库与模式）
- 表/视图/动态表/命名/分区/约束
