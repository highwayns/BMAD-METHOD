# Domain Data Map（域与数据地图）
- 业务域→实体→指标
