# Snowpark ML 计划
- 特征/训练/评估/部署
