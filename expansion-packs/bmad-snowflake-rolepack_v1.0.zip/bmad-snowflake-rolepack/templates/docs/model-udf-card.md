# Model/UDF Card（模型/函数卡片）
- 训练/指标/偏差/监控
