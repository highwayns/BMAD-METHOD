# RBAC Role Hierarchy（角色层次）
- 角色/授权/最小权限/回滚
