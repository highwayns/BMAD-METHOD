# Snowpipe 设计
- Pipe 定义/通知/重放/幂等
