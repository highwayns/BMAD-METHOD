from snowflake.snowpark import Session
def get_session():
    return Session.builder.configs({
        "account": "${ACCOUNT}",
        "user": "<USER>",
        "password": "<PASSWORD>",
        "role": "${ROLE}",
        "warehouse": "${WAREHOUSE}",
        "database": "${DATABASE}",
        "schema": "${SCHEMA}",
    }).create()
