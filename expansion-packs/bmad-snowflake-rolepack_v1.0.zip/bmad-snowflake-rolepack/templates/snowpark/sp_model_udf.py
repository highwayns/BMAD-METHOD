# Model UDF (Python UDF) placeholder
# CREATE OR REPLACE FUNCTION ${DATABASE}.${SCHEMA}.predict(x FLOAT) RETURNS FLOAT LANGUAGE PYTHON RUNTIME_VERSION=3.10 HANDLER='predict' AS $$
# def predict(x):
#     return x
# $$;
