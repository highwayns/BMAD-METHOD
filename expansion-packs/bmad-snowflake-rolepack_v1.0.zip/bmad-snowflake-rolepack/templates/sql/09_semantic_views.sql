-- Semantic Views (example)
CREATE OR REPLACE VIEW ${DATABASE}.${SCHEMA}.v_sales_daily AS
SELECT order_date, SUM(amount) AS revenue
FROM ${DATABASE}.${SCHEMA}.gold
GROUP BY order_date;