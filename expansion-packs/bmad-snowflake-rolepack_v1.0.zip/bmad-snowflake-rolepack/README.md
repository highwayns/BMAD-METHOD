# BMAD-Method｜基于 Snowflake 的系统开发（Data Cloud）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：架构/契约/ELT/Streaming/动态表/语义层/Snowpark/RBAC/CI-CD/监控/FinOps 模板 + SQL + CSV
- checklists：质量门/RBAC/安全隐私/FinOps/可观测/变更/反模式
- delivery：打包与合并规则
