# BMAD-Method｜基于 Databricks 的系统开发（Lakehouse）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：架构/契约/DLT/Jobs/BI/ML/UC/CI-CD/监控/FinOps 模板 + 代码 + CSV
- checklists：质量门/Delta-UC/安全隐私/FinOps/可观测/变更/反模式
- delivery：打包与合并规则
