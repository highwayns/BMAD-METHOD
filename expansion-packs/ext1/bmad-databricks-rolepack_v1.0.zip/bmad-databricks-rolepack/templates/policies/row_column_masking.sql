-- Row/Column level masking example
CREATE OR REPLACE VIEW ${catalog}.${schema}.masked_customers AS
SELECT *, CASE WHEN is_member('pii_viewers') THEN email ELSE '***' END AS email_masked
FROM ${catalog}.${schema}.customers;