-- Example UC grants
GRANT USAGE ON CATALOG ${catalog} TO `data_scientists`;
GRANT SELECT ON SCHEMA ${catalog}.${schema} TO `analysts`;