from pyspark.sql import functions as F
rules = [("not_null_order_id","order_id IS NOT NULL"),("amount_positive","amount > 0")]
df = spark.table("${catalog}.${schema}.silver_sales")
violations = [(name, df.filter(f"NOT ({expr})").count()) for name, expr in rules]
print(violations)
