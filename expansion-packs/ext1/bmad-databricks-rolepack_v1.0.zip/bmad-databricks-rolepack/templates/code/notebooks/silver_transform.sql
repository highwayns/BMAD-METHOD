-- Databricks SQL
CREATE OR REPLACE TABLE ${catalog}.${schema}.silver_sales AS
SELECT CAST(order_id AS STRING) AS order_id,
       customer_id,
       amount::DOUBLE AS amount,
       to_date(order_ts) AS order_date,
       current_timestamp() AS _etl_ts
FROM ${catalog}.${schema}.bronze_sales
WHERE amount IS NOT NULL;