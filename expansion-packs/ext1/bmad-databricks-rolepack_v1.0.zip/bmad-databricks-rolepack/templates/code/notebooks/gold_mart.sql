-- Databricks SQL
CREATE OR REPLACE TABLE ${catalog}.${schema}.gold_sales_daily AS
SELECT order_date, SUM(amount) AS revenue
FROM ${catalog}.${schema}.silver_sales
GROUP BY order_date;