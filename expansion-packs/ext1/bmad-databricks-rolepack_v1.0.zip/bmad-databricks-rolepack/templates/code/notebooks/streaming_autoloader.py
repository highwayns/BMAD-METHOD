from pyspark.sql import functions as F
df = (spark.readStream.format("cloudFiles")
      .option("cloudFiles.format","json")
      .option("cloudFiles.inferColumnTypes","true")
      .load("${src_path}"))
df = df.withColumn("_ingest_time", F.current_timestamp())
(df.writeStream
    .format("delta")
    .option("checkpointLocation","${checkpoint}")
    .trigger(availableNow=True)
    .toTable("${catalog}.${schema}.bronze_stream"))
