# Databricks notebook source
from pyspark.sql import functions as F
def ingest(src_path, table_fullname):
    df = spark.read.format("json").load(src_path)
    df = df.withColumn("_ingest_time", F.current_timestamp())
    df.write.format("delta").mode("append").saveAsTable(table_fullname)
    return df.count()
