import dlt
from pyspark.sql.functions import current_timestamp
@dlt.table
def bronze_sales():
    return (spark.read.format("json").load("${src_path}")
            .withColumn("_ingest_time", current_timestamp()))
@dlt.table
def silver_sales():
    return dlt.read("bronze_sales").withColumn("_etl_ts", current_timestamp())
