def predict(request_json):
    return {"ok": True, "input": request_json}
