# Databricks notebook for ML experiment
import mlflow, uuid
mlflow.set_experiment("/Shared/${project}/exp")
with mlflow.start_run(run_name=f"exp-{uuid.uuid4().hex[:6]}"):
    mlflow.log_param("model","baseline"); mlflow.log_metric("accuracy", 0.9)
