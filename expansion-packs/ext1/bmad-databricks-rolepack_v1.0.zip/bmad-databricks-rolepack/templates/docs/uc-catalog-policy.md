# UC Catalog Policy（治理策略）
- Catalog/Schema/Object/Grants
