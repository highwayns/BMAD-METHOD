# Model Card（模型卡）
- 训练/指标/偏差/监控
