# Cluster Policy（集群策略）
- 实例/自动停止/标签
