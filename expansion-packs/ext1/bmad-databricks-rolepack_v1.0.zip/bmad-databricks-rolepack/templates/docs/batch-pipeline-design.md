# Batch Pipeline Design（批处理）
- 源/变换/加载/回填
