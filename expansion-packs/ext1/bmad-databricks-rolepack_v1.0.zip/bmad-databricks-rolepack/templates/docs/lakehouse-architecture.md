# Lakehouse Architecture（架构）
- 域模型/表层级/权限/成本/可观测
