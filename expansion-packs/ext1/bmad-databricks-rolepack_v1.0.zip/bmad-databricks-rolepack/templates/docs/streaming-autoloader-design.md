# Streaming Autoloader（流式摄取）
- 模式/幂等/窗口
