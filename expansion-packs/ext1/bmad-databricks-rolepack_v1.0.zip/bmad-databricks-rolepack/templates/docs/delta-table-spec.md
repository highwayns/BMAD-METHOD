# Delta Table Spec（表规范）
- 分区/约束/审计列/OPTIMIZE/ZORDER
