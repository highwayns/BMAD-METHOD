# Data Contract（数据契约）
- Schema/约束/SLA/SLO/隐私/变更
