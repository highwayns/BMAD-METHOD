# FinOps Budget Policy（成本策略）
- 预算/上限/告警/优化
