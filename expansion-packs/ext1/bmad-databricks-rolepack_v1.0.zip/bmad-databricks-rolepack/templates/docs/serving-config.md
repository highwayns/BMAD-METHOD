# Serving Config（服务配置）
- 端点/资源/SLA
