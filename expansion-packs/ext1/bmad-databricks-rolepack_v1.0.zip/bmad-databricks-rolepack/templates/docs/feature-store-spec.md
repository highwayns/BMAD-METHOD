# Feature Store Spec（特征仓库）
- 实体/特征/新鲜度/一致性
