# Silver→Gold Modeling（建模）
- 维度/事实/度量/语义层
