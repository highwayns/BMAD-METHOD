# DLT Design（Delta Live Tables）
- 依赖图/期望/检查点
