# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| BA/Contract | Architect | Contract Locked | docs/data-contract.md | docs/delta-table-spec.md | 命名/口径一致 |
| Architect | Data Eng/Streaming | UC Policy Ready | docs/uc-catalog-policy.md | docs/dlt-design.md | DLT/Autoloader 跑通 |
| DE/AE | QA/Release | Gold DQ Passed | data/dq_rules.csv + 测试报告 | ci-cd/github-actions-databricks.yml | CI 通过 |
| ML | Serving/Obs | Model Staged | docs/model-card.md | docs/serving-config.md | 端点健康、SLO 告警 |
| FinOps/Obs | Platform | Monthly Bill | data/kpi.csv + data/cost_budgets.csv | 优化建议 | 成本回归目标 |
