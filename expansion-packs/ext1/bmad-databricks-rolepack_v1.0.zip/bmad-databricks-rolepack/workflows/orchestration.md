# Orchestration（编排操作手册）
Use Case → Contract → Lakehouse Arch → DLT/Jobs（Bronze→Silver→Gold）→ Feature/Model/Serving → Governance（UC/Privacy）→ CI/CD → Observability & FinOps → Ops/Backfill/Postmortem

## 常用命令（示例）
- `*agent business-analyst → *create-doc data-contract`
- `*agent lakehouse-architect → *create-doc lakehouse-architecture`
- `*agent data-engineering-lead → *create-doc dlt-design`
- `*agent analytics-engineer-bisql → *create-doc silver-to-gold-modeling`
- `*agent ml-engineer-mlops → *create-doc model-card`
- `*agent security-and-governance-unity-catalog → *create-doc uc-catalog-policy`
- `*agent release-and-change-manager → *create-doc ci-cd-guide`
