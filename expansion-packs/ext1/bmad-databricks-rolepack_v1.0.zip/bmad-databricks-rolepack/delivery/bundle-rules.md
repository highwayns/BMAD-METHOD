# 打包与归档规则
- 关键节点（Contract/Arch/DLT/Gold/Serving/Release）执行 *bundle：生成清单、校验哈希、版本快照
- 文档/代码/数据分仓；审计日志同行
