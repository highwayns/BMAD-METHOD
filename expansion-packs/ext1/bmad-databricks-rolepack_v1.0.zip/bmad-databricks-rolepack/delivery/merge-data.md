# 数据合并与对账（CSV/Delta）
- 主键：catalog/schema/table + 日期窗口
- 统一日期/数值/口径格式，生成校验报告
