# Delta/UC 最佳实践
- 审计列/OPTIMIZE/ZORDER/软删除/时间旅行；UC 精细授权
