# DoR / DoD（按阶段）
- 合同：口径/SLA/SLO/隐私；DoD：data-contract 发布并获签
- 架构：表/流/特征/权限；DoD：delta-spec + uc-policy 发布
- 实现：DLT/Jobs 可复现；DoD：dlt-design + 集成测试通过
- Gold：语义层与 DQ；DoD：DQ 报告全绿
- ML/Serving：模型卡/监控；DoD：serving-config 生效
- 发布/运营：CI/CD + 监控；DoD：actions 成功 + monitoring 生效
