# Differentiation / Organoid Protocol（记录用框架）
- 目标表型/里程碑（非操作性）：
- 记录要求（采样点标识/时间戳，不含步骤）
