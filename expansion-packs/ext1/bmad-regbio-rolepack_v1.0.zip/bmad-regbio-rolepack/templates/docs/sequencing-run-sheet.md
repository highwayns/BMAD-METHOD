# Sequencing Run Sheet（记录用框架）
- RUN_ID/项目键：
- 元数据字段（平台/批注），不含实验条件：
