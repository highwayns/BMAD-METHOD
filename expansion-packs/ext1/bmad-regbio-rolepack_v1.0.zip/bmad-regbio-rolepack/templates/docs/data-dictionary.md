# Data Dictionary（键与口径）
- 主键/外键：
- 字段定义与口径：
