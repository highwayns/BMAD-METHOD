# Culture Log（记录框架）
- 批次键：${BATCH_ID}；传代编号：${PASSAGE}
- 责任人/时间戳；备注（非操作性）
- 关联 QC 记录键：
