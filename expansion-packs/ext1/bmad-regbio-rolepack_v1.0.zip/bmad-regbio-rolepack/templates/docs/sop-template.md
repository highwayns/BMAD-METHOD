# SOP Template（管理用模板｜不含实验步骤）
- 目的（Purpose）：本文件仅定义文档与记录要求
- 适用范围（Scope）：
- 角色与职责（Roles）：
- 记录与留痕（Records & Traceability）：
- 变更控制与培训记录（Change & Training）：
