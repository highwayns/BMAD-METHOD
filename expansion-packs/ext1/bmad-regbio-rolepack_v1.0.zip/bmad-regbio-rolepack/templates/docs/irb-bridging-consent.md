# IRB/Consent Bridging（仅记录要素）
- 伦理审查编号：
- 同意类型与存档位置：
