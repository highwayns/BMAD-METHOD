# Cell Line Passport（记录框架）
- 细胞系标识：${CELL_LINE}
- 来源/鉴定（STR/Myco 状态引用，不含检测条件）
- 关联同意/MTA：
