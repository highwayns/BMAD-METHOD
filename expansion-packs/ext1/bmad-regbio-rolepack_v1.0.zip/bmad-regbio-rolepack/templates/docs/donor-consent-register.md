# Donor Consent Register
- DONOR_ID：来源/同意类型/日期（不含敏感细节）
- 访问与保留策略：
