# ELN/LIMS 命名策略
- 键结构：${PROJECT}_${CELL_LINE}_${BATCH_ID}_${STEP}
- 版本与留痕：
