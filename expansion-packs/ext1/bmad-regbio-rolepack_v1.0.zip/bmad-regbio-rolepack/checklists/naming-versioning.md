# 命名与版本
- `{PROJECT}_{CELL_LINE}_{BATCH_ID}_{STEP}_vX.Y_YYYYMMDD.ext`
- CSV UTF-8，日期 ISO-8601；键需唯一且可追溯
