# DoR / DoD（按阶段｜非操作性）
- Cell Bank DoR：来源/同意/护照登记；DoD：cell-bank.csv 入库
- Records DoR：模板字段齐全；DoD：批次/筛选/QC 记录可追溯
- Omics DoR：元数据齐全；DoD：sequencing-runs.csv 入库
- Transfer DoR：清单齐备；DoD：tech-transfer-pack.md 完成
