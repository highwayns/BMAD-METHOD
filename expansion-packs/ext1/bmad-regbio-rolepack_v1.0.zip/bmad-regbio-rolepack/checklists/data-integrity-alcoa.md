# 数据诚信（ALCOA+）
- Attributable/Legible/Contemporaneous/Original/Accurate
- Complete/Consistent/Enduring/Available
