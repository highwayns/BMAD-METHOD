# 文档合并（非操作性）
- 分片（shard）→ 回填主文档
- 生成 merge-report 并记录冲突处理
