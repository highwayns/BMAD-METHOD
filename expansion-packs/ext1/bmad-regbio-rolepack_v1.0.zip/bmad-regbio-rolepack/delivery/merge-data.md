# 数据合并（CSV/Excel）
- 使用唯一键（batch_id / sample_id / run_id）合并
- 统一日期/数值格式，输出校验报告
