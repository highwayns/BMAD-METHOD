# 交接契约（Handoff Contracts｜非操作性）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Compliance | Biobank | Consent & Passport Ready | docs/donor-consent-register.md | data/samples-metadata.csv | 字段齐全、键可追溯 |
| Biobank | Cell Culture | Bank Registered | data/cell-bank.csv | docs/culture-log.md | 记录字段齐全 |
| Records Admin | QC | Records Present | docs/batch-record.md | data/qc-assays.csv | 字段口径一致 |
| QC | Omics | Metadata Ready | docs/qc-panel.md | data/sequencing-runs.csv | 元数据完整 |
| Omics | Bioinformatics | Metadata Complete | data/reads-metadata.csv | docs/data-dictionary.md | 数据字典通过 |
| Review | Tech Transfer | Review Pass | docs/* | docs/tech-transfer-pack.md | 文档清单齐备 |
