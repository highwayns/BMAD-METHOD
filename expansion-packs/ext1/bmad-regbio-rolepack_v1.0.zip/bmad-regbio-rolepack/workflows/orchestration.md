# Orchestration（编排操作手册｜非操作性）

## 节拍（管理归档视角）
1. 立项 → 2. 合规（IBC/IRB/MTA） → 3. 细胞库登记 → 4. 记录与清单（设计/批/筛选/采样等，不含实验步骤） → 5. QC 面板字段登记 → 6. 组学元数据登记 → 7. 评审与报告 → 8. 技术转移包 → 9. 打包归档

## 常用命令（示例）
- `*agent orchestrator → *plan "P0-再生生物实验室建盘"`
- `*agent cell-culture-lead → *create-doc cell-line-passport`
- `*agent gene-editing-crispr → *create-doc batch-record`
- `*agent analytical-qc-assay → *create-doc qc-panel`
- `*agent eln-lims-platform → *bundle`

> 说明：本手册仅描述**文档与数据的字段与流转**，不包含任何程序、条件或实验配方。
