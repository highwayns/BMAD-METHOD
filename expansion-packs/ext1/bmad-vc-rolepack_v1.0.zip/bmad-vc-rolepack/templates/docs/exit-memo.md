# Exit Memo（退出备忘录）
- 买方/条款/回报
