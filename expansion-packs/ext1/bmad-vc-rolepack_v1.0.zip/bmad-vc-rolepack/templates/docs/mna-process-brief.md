# M&A Process Brief（并购过程）
- FA/对赌/交割路径
