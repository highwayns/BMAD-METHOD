# Tech DD Checklist（技术尽调清单）
- 架构/安全/研发/合规
