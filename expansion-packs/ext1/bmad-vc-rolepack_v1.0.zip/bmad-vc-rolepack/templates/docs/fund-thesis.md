# Fund Thesis（投资论文）
- 赛道/阶段/优势/边界
