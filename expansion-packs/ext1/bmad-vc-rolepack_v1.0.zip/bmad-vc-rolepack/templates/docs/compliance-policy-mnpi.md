# MNPI Policy（重大非公开信息）
- 定义/隔离/审批
