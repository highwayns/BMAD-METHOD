# Unit Economics Model（单位经济）
- CAC/LTV/毛利/回收期
