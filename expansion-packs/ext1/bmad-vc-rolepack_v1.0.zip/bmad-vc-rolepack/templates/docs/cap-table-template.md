# Cap Table Template（股权结构）
- 股东/期权/稀释
