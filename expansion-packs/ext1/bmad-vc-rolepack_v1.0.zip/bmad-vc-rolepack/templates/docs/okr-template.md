# OKR Template（目标管理）
- 目标/关键结果/负责人
