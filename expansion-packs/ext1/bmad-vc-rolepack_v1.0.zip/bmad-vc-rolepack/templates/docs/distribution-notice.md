# Distribution Notice（分配通知）
- 金额/依据/税务
