# SHA/SPA Checklist（协议清单）
- 先决条件/交割文件
