# KPI Dictionary（指标）
- TVPI/DPI/IRR/NRR/EBITDA
