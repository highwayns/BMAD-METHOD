# DoR / DoD（按阶段）
- Screening：onepager + NDA；DoD：进入数据室
- DD：tech/financial/legal 闭环；DoD：DD Pack + 估值说明
- IC：纪要与决议编号；DoD：ic-memo 发布
- TS/Closing：文件签署完毕；DoD：closing-checklist 全绿
- Post：100D 执行；DoD：portco_kpis 周期产出
- Exit：回报核算与披露；DoD：exit-memo + distribution-notice 归档
