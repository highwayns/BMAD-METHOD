# BMAD-Method｜风险投资（Venture Capital）管理团队 RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：募资/投前/尽调/投决/条款/交割/投后/退出/合规模板 + CSV 数据
- checklists：质量门/数据室治理/估值与合规/MNPI/AML/KYC/安全/反模式
- delivery：打包与合并规则
