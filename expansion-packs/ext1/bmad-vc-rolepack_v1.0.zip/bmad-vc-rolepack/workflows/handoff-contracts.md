# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Origination | Research/TechDD | NDA Executed | docs/screening-onepager.md | docs/product-teardown.md | 数据室开启 |
| DD/Valuation | Investment Committee | DD Pack Ready | docs/dd-checklist-*.md + 模型 | docs/ic-memo.md | 立项/否决/待补 |
| IC | Transaction | IC Approved | docs/ic-memo.md | docs/term-sheet.md | TS 签署 |
| Transaction/Legal | PortfolioOps | Closing Complete | docs/closing-checklist.md | docs/100-day-plan.md | 投后启动 |
| PortfolioOps | IR & Data | Quarter Close | data/portco_kpis.csv | docs/lp-quarterly-update.md | LP 回执 |
| Exit | IR/Finance | SPA Signed | docs/exit-memo.md | docs/distribution-notice.md | 分配完成 |
