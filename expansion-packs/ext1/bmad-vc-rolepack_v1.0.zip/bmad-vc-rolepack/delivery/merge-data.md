# 数据合并（CSV/Excel）
- 主键：deal_id / company / period / metric
- 统一日期/货币/数值格式，生成校验报告
