# Lab Request（检验申请）
- MRN：${MRN} / ENC：${ENC_ID} / ORDER：${ORDER_ID}
- 项目/标本/容器/采集时间：
- 注意：危急值回报路径：
