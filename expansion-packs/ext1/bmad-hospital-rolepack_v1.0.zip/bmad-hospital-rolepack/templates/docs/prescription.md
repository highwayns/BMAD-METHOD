# Prescription & MAR
- MRN：${MRN} / ENC：${ENC_ID}
- 处方明细（药品/剂量/频次/天数）：
- MAR 给药记录（时间/执行人/备注）：
