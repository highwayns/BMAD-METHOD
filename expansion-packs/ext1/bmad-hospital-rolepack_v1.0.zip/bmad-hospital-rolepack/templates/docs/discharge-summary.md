# Discharge / Referral Summary
- 诊断/治疗：
- 出院用药/随访计划：
- 注意事项与红旗症状：
