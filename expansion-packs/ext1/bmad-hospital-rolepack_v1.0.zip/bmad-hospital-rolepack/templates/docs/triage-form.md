# Triage Form（分诊）
- MRN：${MRN} / ENC：${ENC_ID}
- 主诉/生命体征：
- 过敏史/危急症状筛查：
- 分级与优先级：
