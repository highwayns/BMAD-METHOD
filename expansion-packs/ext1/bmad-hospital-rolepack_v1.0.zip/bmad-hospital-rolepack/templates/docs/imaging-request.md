# Imaging Request（影像申请）
- MRN：${MRN} / ENC：${ENC_ID} / ORDER：${ORDER_ID}
- 检查部位/序列/参数：
- 预约时间与准备事项：
