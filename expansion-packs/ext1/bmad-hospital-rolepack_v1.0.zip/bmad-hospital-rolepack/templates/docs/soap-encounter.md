# SOAP Encounter
- MRN：${MRN} / ENC：${ENC_ID}
- S（主观）：
- O（客观/体征/检验要点）：
- A（评估/诊断）：
- P（计划/随访）：
