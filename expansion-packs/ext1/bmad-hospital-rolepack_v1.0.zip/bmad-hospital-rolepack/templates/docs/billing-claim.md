# Billing / Claims
- MRN：${MRN} / ENC：${ENC_ID}
- 诊断编码/手术编码：
- 项目清单与金额：
