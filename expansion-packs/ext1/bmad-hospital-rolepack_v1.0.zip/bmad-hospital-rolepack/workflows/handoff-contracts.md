# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Front Desk | Triage Nurse | Registration Complete | docs/patient-intake.md | docs/triage-form.md | Vitals & Queue OK |
| Physician | Lab | Orders Signed | docs/order-cpoe.md | docs/lab-request.md | Specimen Labeled/Barcoded |
| Physician | Imaging | Orders Signed | docs/order-cpoe.md | docs/imaging-request.md | Slot Booked & Protocol Set |
| Physician | Pharmacy | Orders Signed | docs/order-cpoe.md | data/meds-dispense.csv | 5R Checked/MAR Logged |
| Nursing | Billing | MAR Updated | docs/prescription.md | data/billing-lines.csv | Coding Ready |
| Physician | Care Coordinator | Discharge/Referral | docs/referral-letter.md | docs/referral-followup.md | Appointment Confirmed |
| Billing | Finance | Claim Ready | docs/billing-claim.md | - | Payer Submission Receipt |
