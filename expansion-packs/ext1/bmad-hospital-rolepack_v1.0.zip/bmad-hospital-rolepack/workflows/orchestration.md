# Orchestration（编排操作手册）

## 节拍（Outpatient）
1. Registration → 2. Triage → 3. Encounter (SOAP) → 4. CPOE → 5. Lab/Imaging → 6. Results → 7. Rx/MAR → 8. Discharge/Referral → 9. Billing → 10. Quality/IPC → 11. Analytics

## 常用命令
- 初始化：`*agent orchestrator → *plan "P0-医院团队建盘"`
- 排班/诊室：`*agent clinic-ops-manager → *create-doc schedule-roster`
- 门诊记录：`*agent attending-physician → *create-doc soap-encounter`
- 事件上报：`*agent quality-safety-officer → *create-doc incident-report`
- 打包：`*agent it-emr-platform → *bundle`

## 触发器
- Triage Start：Registration Complete
- Orders Sign：Encounter Recorded
- Result Review：Results Available
- Billing Submit：Coding Ready
