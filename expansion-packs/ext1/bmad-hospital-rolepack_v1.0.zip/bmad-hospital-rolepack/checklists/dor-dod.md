# DoR / DoD（按阶段）
- Registration DoR：身份核验/同意书/隐私宣讲；DoD：intake 入库+MRN
- Orders DoR：过敏史/禁忌完成；DoD：CPOE 签名+相容性校验通过
- Pharmacy DoR：医嘱有效；DoD：5R 勾选、MAR 回写
- Imaging/Lab DoR：申请单与条码；DoD：报告回填并通知
- Billing DoR：编码齐套；DoD：提交回执与对账完成
