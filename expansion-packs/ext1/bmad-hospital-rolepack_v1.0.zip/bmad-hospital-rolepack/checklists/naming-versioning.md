# 命名与版本
- `{MRN}_{ENC_ID}_{DOC}_vX.Y_YYYYMMDD.ext`
- CSV UTF-8，日期 ISO-8601；敏感字段脱敏或置换键
