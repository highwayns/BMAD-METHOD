# BMAD-Method｜教育培训（Education & Training Ops）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：需求/课程/教学设计/内容/LMS/考试/招生/服务/评估模板 + CSV 数据
- checklists：质量门/隐私与合规/无障碍/测评 QA/LMS QA/变更/反模式
- delivery：打包与合并规则
