# 命名与版本
- `EDU_${PROGRAM}_${TERM}_${COURSE}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；重大变更需通知与回执
