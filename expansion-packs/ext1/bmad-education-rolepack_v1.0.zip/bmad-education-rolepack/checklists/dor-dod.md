# DoR / DoD（按阶段）
- Design：需求与课程地图明确；DoD：syllabus/lesson-plan/assessment-blueprint 完成
- Content & LMS：素材齐套/结构上线；DoD：lms-course-setup 通过、无障碍检查通过
- Delivery & Assessment：出勤与评分留痕；DoD：attendance/grades 完整、exam-incident-report（若有）
- Evaluation & Improvement：KPI 与评估汇总；DoD：kpi.csv、course-evaluation、improvement-plan 发布
