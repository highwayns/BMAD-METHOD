# 反模式与对策
- 只有内容无测评 → 引入测评蓝图
- 口头改动无留痕 → 使用 decision-log 与 audit_log
- 无障碍缺失 → 强制 A11y 检查门
- 数据不审计 → 强制 lms_logs/audit_log
