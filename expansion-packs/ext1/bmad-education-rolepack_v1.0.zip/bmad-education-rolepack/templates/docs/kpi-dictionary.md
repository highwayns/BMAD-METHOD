# KPI Dictionary（指标字典）
- 完成率/通过率/满意度/活跃度/就业率
