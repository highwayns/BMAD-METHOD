# Academic Integrity（学术诚信）
- 抄袭/代写/处理
