# Universal Design Guidelines（通用设计）
- 多路径/可选性/弹性
