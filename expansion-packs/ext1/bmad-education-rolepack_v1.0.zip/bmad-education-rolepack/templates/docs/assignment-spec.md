# Assignment Spec（作业说明）
- 目的/提交/评分
