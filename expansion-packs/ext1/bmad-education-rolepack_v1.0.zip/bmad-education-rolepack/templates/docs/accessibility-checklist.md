# Accessibility Checklist（可访问性）
- 字幕/替代文本/对比度/键盘操作
