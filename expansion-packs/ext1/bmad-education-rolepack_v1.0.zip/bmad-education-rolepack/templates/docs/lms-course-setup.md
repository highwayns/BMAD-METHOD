# LMS Course Setup（课程搭建）
- 结构/权限/追踪/测试
