# Program Brief（项目简介）
- PROGRAM/TERM/范围/KPI
- 师资/预算/风险
