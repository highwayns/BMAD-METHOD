# Enrollment Flow（入学流程）
- 报到/注册/缴费
