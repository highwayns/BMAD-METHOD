# Grading Policy（评分政策）
- 均衡/迟交/申诉
