# LMS Data Export（数据导出）
- 字段/周期/口径
