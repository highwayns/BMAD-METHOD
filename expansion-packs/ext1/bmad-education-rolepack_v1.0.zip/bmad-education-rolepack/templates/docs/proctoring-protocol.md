# Proctoring Protocol（监考）
- 身份核验/环境/记录
