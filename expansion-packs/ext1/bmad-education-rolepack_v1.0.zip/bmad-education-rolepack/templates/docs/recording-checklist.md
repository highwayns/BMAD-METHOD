# Recording Checklist（录制清单）
- 设备/环境/脚本/留痕
