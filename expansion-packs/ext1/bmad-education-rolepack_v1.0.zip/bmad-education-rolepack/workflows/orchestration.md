# Orchestration（编排操作手册）

## 节拍
Needs → Curriculum → Instructional Design → Content → LMS Setup → Delivery → Assessment → Evaluation → Continuous Improvement

## 常用命令
- `*agent curriculum-architect → *create-doc curriculum-map`
- `*agent instructional-designer → *create-doc syllabus`
- `*agent content-production-and-media → *create-doc media-production-brief`
- `*agent lms-admin-and-learning-tech → *create-doc lms-course-setup`
- `*agent assessment-and-accreditation-lead → *create-doc assessment-blueprint`
- `*agent learning-analytics-and-outcomes → *create-doc postmortem-report`

## 触发器
- Curriculum Map vX.Y：进入教学设计
- Syllabus Approved：内容制作启动
- Assets Locked：LMS 课程搭建
- Course Open：开始授课与记录
- Course Closed：评估与分析
- Improvement Published：滚动改进
