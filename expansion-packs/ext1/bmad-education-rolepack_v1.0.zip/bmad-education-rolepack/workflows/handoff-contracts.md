# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Curriculum Architect | Instructional Designer | Curriculum Map vX.Y | docs/curriculum-map.md | docs/syllabus.md | LO-活动-测评一致 |
| Instructional Designer | Content Production | Syllabus Approved | docs/syllabus.md | docs/media-production-brief.md | 素材可制作 |
| Content/ID | LMS Admin | Assets Locked | docs/lesson-plan.md + 资产清单 | docs/lms-course-setup.md | 课程结构上线 |
| Assessment Lead | Exam Ops | Assessment Blueprint Ready | docs/assessment-blueprint.md | docs/proctoring-protocol.md | 考试合规可执行 |
| Delivery (Instructors) | Analytics | Course Closed | data/grades.csv + data/evaluations.csv | data/kpi.csv + docs/postmortem-report.md | 改进项发布 |
