# DoR / DoD（按阶段）
- Enrollment DoR：同意有效/身份核验/设备库存；DoD：patients.csv 入库，pairings.csv 成功
- Data Ingest DoR：数据字典与映射完成；DoD：signals.csv 连续性与时序校验通过
- Alerting DoR：规则口径与审批；DoD：alerts.csv 误报率/漏报抽检达标
- Triage/Telemed DoR：排班与准入；DoD：triage-decisions.csv / teleconsults.csv 完整，careplans.csv 回写
