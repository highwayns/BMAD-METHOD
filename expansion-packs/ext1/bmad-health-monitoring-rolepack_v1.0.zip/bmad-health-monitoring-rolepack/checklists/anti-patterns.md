# 反模式与对策
- 未入组即发设备 → 先执行 Enrollment DoR
- 未脱敏即导出数据 → 强制审计与遮蔽
- 以口头分诊替代表单 → 使用 triage-decisions.csv
- 频繁改规则但不留痕 → 使用 alert-triage-rubric 与变更记录
