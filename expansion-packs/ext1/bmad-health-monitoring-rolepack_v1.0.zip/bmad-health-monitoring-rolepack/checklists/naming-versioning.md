# 命名与版本
- `{PROGRAM}_{PAT_ID}_{DEVICE_ID}_{DOC}_vX.Y_YYYYMMDD.ext`
- CSV UTF-8，日期 ISO-8601；版本语义化递增
