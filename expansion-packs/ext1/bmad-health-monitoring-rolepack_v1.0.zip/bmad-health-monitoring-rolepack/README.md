# BMAD-Method 健康监控 RolePack
- 18 个角色独立文件（人格/任务/模板/编排/DoR/DoD）
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：入组/设备/数据/告警/分诊/随访/合规/运维模板
- checklists：质量门/命名与版本/数据诚信/隐私与合规/安全/变更/反模式
- delivery：打包与合并规则
