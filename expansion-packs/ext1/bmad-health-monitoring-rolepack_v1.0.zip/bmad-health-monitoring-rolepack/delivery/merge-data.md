# 数据合并（CSV/Excel）
- 使用主键（pat_id / device_id / alert_id / enc_id）合并
- 统一日期/数值格式，输出校验报告
