# Orchestration（编排操作手册）

## 节拍
Enrollment → Device Provisioning → Data Ingest → Signal QA → Alerting → Triage → Teleconsult → Care Plan → Follow-up → Analytics/Reporting → Billing（可选）

## 常用命令
- 初始化：`*agent orchestrator → *plan "P0-健康监控团队建盘"`
- 集成：`*agent integration-data-ingest → *create-doc data-schema`
- 分诊：`*agent triage-nurse → *create-doc followup-call-log`
- 打包：`*agent platform-automation → *bundle`

## 触发器
- Pairing Done：Enrollment 完成并配对成功
- QA OK：数据接入稳定且连续
- Alert Fired：规则命中
- Triage Closed：分诊记录完成
- Teleconsult Complete：会诊记录完成
- Report Published：KPI 聚合出具
