# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Enrollment | Device Ops | Consent Recorded | docs/patient-enrollment.md | data/patients.csv | Pairing Ready |
| Device Ops | Integration | Pairing Done | data/pairings.csv | docs/data-schema.md | Data Flow Alive |
| Integration | Signal QA | Feed Stable | data/signals.csv | - | Continuity ≥ SLA |
| QA | Alert Governance | QA OK | data/signals.csv | docs/alert-triage-rubric.md | Rule Set Approved |
| Triage | Telemed | Escalate | data/triage-decisions.csv | docs/teleconsult-soap.md | SOAP Recorded |
| Telemed | Care Plan | Teleconsult Complete | docs/teleconsult-soap.md | docs/care-plan.md | Plan Updated |
| Care Plan | Analytics | Plan Active | data/careplans.csv | data/kpi.csv | KPI Aggregated |
