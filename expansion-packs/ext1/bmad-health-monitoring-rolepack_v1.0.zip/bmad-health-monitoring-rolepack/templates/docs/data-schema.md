# Data Schema（数据字典）
- 键与字段：PAT_ID/DEVICE_ID/TS/CHANNEL/VALUE/UNIT
- 事件与状态：ALERT_ID/ENC_ID
- 口径与单位约定
