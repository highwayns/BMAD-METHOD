# Device Return / RMA
- 设备标识/状态
- 故障/归还原因
- 物流与检修记录
