# KPI Dictionary
- Enrollment 完成率、告警关闭SLA、误报率/漏报率
- Teleconsult 完成率、随访达成率、Uptime
