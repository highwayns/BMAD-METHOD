# Device Pairing（设备配对）
- DEVICE_ID：${DEVICE_ID} / 型号/序列/固件版本
- 配对时间戳/责任人
- 自检与连接状态
