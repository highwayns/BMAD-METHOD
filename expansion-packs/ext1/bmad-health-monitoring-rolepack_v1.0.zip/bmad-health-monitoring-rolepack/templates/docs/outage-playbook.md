# Outage Playbook（故障预案）
- 探测→通报→隔离→恢复→复盘
