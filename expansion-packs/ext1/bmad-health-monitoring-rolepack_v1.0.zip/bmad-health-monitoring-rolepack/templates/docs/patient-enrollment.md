# Patient Enrollment（入组）
- PROGRAM：${PROGRAM} / PAT_ID：${PAT_ID}
- 身份核验/联系方式（脱敏存储）
- 同意与隐私声明：签名与时间戳
- 健康状况与纳入/排除概览（非诊疗）
