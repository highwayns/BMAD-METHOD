# FHIR Mapping（映射）
- Observation/Device/Encounter/Profile 映射
- 代码系统与术语集
