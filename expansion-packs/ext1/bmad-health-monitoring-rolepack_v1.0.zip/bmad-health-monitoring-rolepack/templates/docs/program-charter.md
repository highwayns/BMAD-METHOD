# Program Charter（项目章程）
- 目标/范围/角色/节奏/KPI
