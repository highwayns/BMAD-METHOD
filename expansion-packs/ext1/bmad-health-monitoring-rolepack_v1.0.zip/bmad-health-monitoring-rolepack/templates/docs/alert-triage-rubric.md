# Alert & Triage Rubric
- 规则/阈值（摘要）
- 严重度/优先级与SLA
- 升级触发条件
