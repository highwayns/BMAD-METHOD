# Clinical Governance（临床治理）
- 规则/审查/事件管理
