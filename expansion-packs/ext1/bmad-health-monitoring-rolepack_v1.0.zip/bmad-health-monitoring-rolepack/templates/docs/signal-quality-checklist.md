# Signal QA Checklist
- 连续性/丢包/噪声/伪迹抽检
- 校验与抽样策略
