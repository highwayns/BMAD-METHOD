# Clinical Incident Report（临床）
- 事件类型/等级
- 经过与影响
- 纠正/预防
