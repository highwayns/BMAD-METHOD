# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Brand Strategy | Creative | Campaign Brief Approved | docs/campaign-brief.md | docs/creative-brief.md | 资产规格锁定 |
| Creative | Content Production | Creative vX.Y | docs/creative-brief.md | docs/photo-video-shotlist.md | 可拍摄/制作 |
| Content | Channel Owners (Perf/SEO/Social) | Assets Locked | docs/asset-spec-sheet.md | docs/qa-checklist-channel.md | 渠道QA通过 |
| Ops | Perf/SEO/CRM | UTM Issued | docs/utm-governance.md | data/adgroups.csv / data/email_list.csv | 追踪生效 |
| Perf/CRM | Data & Finance | Launch | data/adgroups.csv 等 | data/analytics_kpi.csv / docs/postmortem-report.md | KPI 达标与复盘 |
