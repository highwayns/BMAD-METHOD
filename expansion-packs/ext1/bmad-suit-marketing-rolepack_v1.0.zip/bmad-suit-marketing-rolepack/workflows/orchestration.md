# Orchestration（编排操作手册）

## 节拍
Strategy → Campaign Design → Asset Production → Channel Setup → Launch → Monitor & Optimize → Close & Postmortem

## 常用命令
- `*agent brand-strategy-director → *create-doc campaign-brief`
- `*agent creative-director → *create-doc creative-brief`
- `*agent performance-marketing-lead → *create-doc media-plan`
- `*agent marketing-ops-and-automation → *create-doc utm-governance`
- `*agent data-and-analytics → *create-doc postmortem-report`

## 触发器
- Brief Approved：品牌简报审批通过
- Assets Locked：素材冻结可上线
- UTM Issued：追踪字段生效
- Launch：正式投放与采集数据
- Campaign Closed：进入复盘
