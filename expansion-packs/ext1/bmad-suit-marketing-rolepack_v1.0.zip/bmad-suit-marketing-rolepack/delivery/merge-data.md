# 数据合并（CSV/Excel）
- 主键：campaign_id / adgroup_id / creative_id / sku
- 统一日期/货币/数值格式，生成校验报告
