# 文档合并
- 多版本保留 vX.Y 轨迹与差异说明
- 输出 merge-report
