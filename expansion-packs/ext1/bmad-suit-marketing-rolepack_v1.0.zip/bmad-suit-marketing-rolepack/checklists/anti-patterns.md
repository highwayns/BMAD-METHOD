# 反模式与对策
- 无追踪投放 → 强制 UTM
- 资产无授权 → 法务审查与存证
- KPI 口径不一致 → KPI Dictionary 统一
- 只看曝光不看效率 → 引入 ROAS/CAC
