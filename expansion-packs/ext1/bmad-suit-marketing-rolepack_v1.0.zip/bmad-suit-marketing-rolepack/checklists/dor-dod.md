# DoR / DoD（按阶段）
- Strategy→Design：目标/KPI/预算/受众清晰；DoD：campaign-brief.md 审批
- Production→Setup：素材齐套/规格合规；DoD：asset-spec-sheet.md 完成、qa-checklist-channel.md 通过
- Launch→Optimize：UTM 生效/事件追踪OK；DoD：analytics_kpi.csv 稳定
- Close→Postmortem：KPI 复盘/经验萃取；DoD：postmortem-report.md 发布并回执
