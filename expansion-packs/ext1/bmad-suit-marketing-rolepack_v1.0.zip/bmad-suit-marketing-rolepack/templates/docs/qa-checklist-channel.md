# Channel QA Checklist（渠道质检）
- 链接/UTM/像素/跨端
