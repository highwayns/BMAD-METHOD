# Product Info File（PIF）
- STYLE_CODE/FABRIC/FIT/SKU
- 卖点/尺码/洗护
