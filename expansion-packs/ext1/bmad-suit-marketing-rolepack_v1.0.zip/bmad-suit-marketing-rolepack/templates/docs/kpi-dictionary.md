# KPI Dictionary（指标字典）
- ROAS/CAC/CTR/CR/AOV/库存周转
