# Email Sequence（邮件流程）
- 触发/频次/主题/UTM
