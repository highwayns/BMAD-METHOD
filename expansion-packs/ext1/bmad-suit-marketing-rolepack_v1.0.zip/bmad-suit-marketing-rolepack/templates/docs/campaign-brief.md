# Campaign Brief（活动简报）
- SEASON/CAMPAIGN/KPI/预算
- 核心产品与SKU清单
