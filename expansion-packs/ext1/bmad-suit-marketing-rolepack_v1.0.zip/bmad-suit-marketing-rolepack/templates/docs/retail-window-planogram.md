# Retail Window Planogram（橱窗陈列）
- 视觉/HERO款/更换节奏
