# Training Deck Outline（培训大纲）
- 产品/异议处理/尺码建议
