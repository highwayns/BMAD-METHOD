# Event Run-of-Show（活动流程）
- 时间轴/岗位/物料/应急
