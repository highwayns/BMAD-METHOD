# BMAD-Method｜汽车零件制造（Automotive Parts Manufacturing）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：NPI/APQP/PPAP/生产/质量/供应链/设备/物流/EHS/成本模板 + CSV 数据
- checklists：质量门/追溯与校准/IATF/过程审核/LPA/EHS/变更/反模式
- delivery：打包与合并规则
