# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Process Eng | Quality | CP vX.Y | docs/process-flow.md + docs/pfmea.md + docs/control-plan.md | docs/inspection-plan.md | 关键特性覆盖 |
| Quality/Lab | NPI | MSA/Capability Passed | docs/msa-report-grr.md + docs/capability-study-cpk.md | docs/ppap-checklist.md | PPAP 完整可提交 |
| NPI | Production | PPAP Approved | docs/psw-part-submission-warrant.md | docs/production-readiness-review.md | 量产就绪 |
| Production | Logistics | WO Completed | data/production_log.csv | docs/shipping-plan-asn.md | 按期发运 |
| SQE | Quality | Supplier PPAP | data/supplier_ppap.csv | docs/scar-supplier-corrective-action.md | 缺陷闭环 |
