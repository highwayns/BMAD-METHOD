# Orchestration（编排操作手册）

## 节拍
RFQ → Feasibility → APQP → Product/Process Dev → Tooling Tryout → Run@Rate → PPAP → SOP → Change → CI

## 常用命令
- `*agent program-npi-manager → *create-doc apqp-plan`
- `*agent process-and-manufacturing-engineer → *create-doc control-plan`
- `*agent quality-manager → *create-doc ppap-checklist`
- `*agent metrology-and-lab → *create-doc msa-report-grr`
- `*agent production-supervisor → *create-doc run-at-rate-report`
- `*agent mes-data-it → *create-doc traceability-matrix`

## 触发器
- APQP Plan Published：工程启动
- CP vX.Y Ready：质检计划输出
- MSA/Capability Passed：PPAP 套件可提交
- PPAP Approved：量产就绪
- WO Completed：生成 ASN/发运计划
- Issue Detected：触发 8D 闭环
