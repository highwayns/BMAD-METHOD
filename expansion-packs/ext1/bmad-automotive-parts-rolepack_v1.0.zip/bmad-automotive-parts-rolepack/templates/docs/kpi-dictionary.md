# KPI Dictionary（指标）
- 直通率/报废率/OEE/准时交付
