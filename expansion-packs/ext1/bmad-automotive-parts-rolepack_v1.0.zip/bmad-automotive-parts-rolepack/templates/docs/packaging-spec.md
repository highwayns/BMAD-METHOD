# Packaging Spec（包装规范）
- 材料/堆码/标签
