# PM Checklist（点检）
- 设备/安全/清洁
