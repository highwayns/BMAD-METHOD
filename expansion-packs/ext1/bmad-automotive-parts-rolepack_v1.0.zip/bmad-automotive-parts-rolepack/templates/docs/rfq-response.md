# RFQ Response（报价响应）
- 客户/范围/假设/成本/交期
