# Deviation/Concession（让步）
- 范围/期限/补救
