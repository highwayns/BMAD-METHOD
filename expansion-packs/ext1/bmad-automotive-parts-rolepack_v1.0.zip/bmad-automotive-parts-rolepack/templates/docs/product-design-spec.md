# Product Design Spec（设计规范）
- 图纸/公差/材料/特性
