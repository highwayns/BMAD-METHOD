# OEE Report（综合效率）
- O/A/P/损失
