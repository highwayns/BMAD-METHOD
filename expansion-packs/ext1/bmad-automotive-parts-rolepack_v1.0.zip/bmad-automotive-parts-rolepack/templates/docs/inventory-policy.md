# Inventory Policy（库存策略）
- 安全库存/循环盘点
