# Shipping Plan / ASN（发运计划/预先通知）
- 周期/车次/单据
