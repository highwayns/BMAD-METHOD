# IATF & Core Tools
- APQP/PPAP/FMEA/MSA/SPC/CP 按口径执行并留痕
