# 反模式与对策
- 只有图纸没有特性 → 建立 inspection_characteristics
- MSA 未达标先量产 → 强制门
- Run@Rate 不满载 → 重走试制
- SPC 只报表不处置 → 触发纠偏
- 口头变更无记录 → change_log + CCB
