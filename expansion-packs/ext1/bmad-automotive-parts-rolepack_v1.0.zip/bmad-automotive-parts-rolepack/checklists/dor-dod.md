# DoR / DoD（按阶段）
- APQP 启动：RFQ/可行性评审；DoD：apqp-plan 发布
- 工程定版：DFMEA/PFMEA/CP 完成；DoD：process-flow/control-plan/SOP 齐套
- 试制与能力：MSA/能力研究达标；DoD：msa-report-grr 与 capability-study-cpk 通过
- Run@Rate/PPAP：满负荷稳定；DoD：run-at-rate-report、ppap-checklist、psw 批准
- SOP 量产：追溯/校准/过程审核；DoD：traceability/lpa_results/oee 周期稳定
