# 命名与版本
- `AUTO_${CUSTOMER}_${PROGRAM}_${PART_NO}_${REV}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；破坏性变更需 CCB 冻结点与回执
