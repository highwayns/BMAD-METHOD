# 数据合并（CSV/Excel）
- 主键：group_id / booking_id / itin_id / transfer_id
- 统一日期/币种/数值格式，生成校验报告
