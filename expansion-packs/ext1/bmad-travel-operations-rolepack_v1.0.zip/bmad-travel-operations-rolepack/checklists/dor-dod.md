# DoR / DoD（按阶段）
- Inquiry→Quote：需求清晰/预算区间；DoD：quote-proposal.md 发送且留痕
- Pre-Arrival：签证/订金/库存确认；DoD：rooming-list.md / pnr-flight-summary.md / itinerary-master.md 完成
- Daily Ops：D-1 冻结排程；DoD：daily-run-sheet.md 发放，transfer-order.md/guide-briefing.md 回执
- Close Trip：回款/发票/反馈；DoD：reconciliation.csv 与 invoice.md 归档，feedback.csv 达标
