# 命名与版本
- `TRIP_${GROUP_ID}_${CHECKIN}_${DOC}_vX.Y_YYYYMMDD.ext`
- 版本语义化递增；破坏性变更需通知并回执
