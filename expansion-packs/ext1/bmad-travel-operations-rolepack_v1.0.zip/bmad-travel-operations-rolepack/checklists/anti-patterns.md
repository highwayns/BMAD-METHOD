# 反模式与对策
- 未锁定资源即售卖 → 强制库存校验
- 口头改期未留痕 → 使用 change-request-form + changes.csv
- 行程版本漂移 → 强制 vX.Y 与回执
- 供应商无 SLA → 引入 vendor-contract 与质检
