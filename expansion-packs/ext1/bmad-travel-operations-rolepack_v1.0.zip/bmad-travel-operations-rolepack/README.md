# BMAD-Method 旅游接待（Travel & Hospitality Operations）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：询价/行程/预订/接送/导览/突发/结算/点评模板
- checklists：质量门/隐私合规/安全/变更/反模式
- delivery：打包与合并规则
