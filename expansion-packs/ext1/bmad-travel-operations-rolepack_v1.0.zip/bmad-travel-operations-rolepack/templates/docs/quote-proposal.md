# Quote & Proposal（报价/方案）
- 价格明细（含税/不含税）
- 可选项与有效期
- 版本：v${VERSION}
