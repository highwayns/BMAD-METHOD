# Emergency Playbook（应急）
- 天气/延误/疾病/灾害
- 通报→改签→安抚→复盘
