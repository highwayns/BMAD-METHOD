# Itinerary Master（主行程）
- ITIN_ID / 城市序列 / 里程碑
- 资源清单链接（餐饮/门票/车导）
