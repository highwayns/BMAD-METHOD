# Guide Briefing（导游brief）
- 团况/偏好/注意事项
- 强调留痕与应急
