# Safety Incident（安全事件）
- 等级/伤害/报告链/复盘
