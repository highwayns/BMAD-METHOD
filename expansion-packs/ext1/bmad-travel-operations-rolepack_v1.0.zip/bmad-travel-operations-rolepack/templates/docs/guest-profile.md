# Guest Profile（宾客档案）
- GUEST_ID / 语言 / 联系偏好
- 特殊需求（过敏/无障碍/庆生等）
