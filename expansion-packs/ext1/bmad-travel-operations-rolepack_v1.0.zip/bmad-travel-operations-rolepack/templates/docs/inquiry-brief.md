# Inquiry Brief（询价需求）
- GROUP_ID / GUEST_ID
- 日期区间/人数/预算
- 偏好：酒店/餐饮/活动/交通
