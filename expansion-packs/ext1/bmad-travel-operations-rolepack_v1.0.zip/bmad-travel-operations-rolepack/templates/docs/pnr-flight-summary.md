# PNR & Flight Summary（航班摘要）
- 航段/PNR/起降/行李
- 接机联络
