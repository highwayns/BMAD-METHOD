# Vendor Contract（供应商合约）
- 费率/配额/SLA/赔付
