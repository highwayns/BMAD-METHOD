# VIP Welcome Card（欢迎词）
- 宾客姓名/语言/问候语
- 礼遇/注意事项
