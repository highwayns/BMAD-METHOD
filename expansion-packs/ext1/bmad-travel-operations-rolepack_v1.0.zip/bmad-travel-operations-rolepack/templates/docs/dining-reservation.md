# Dining Reservation（餐饮预订）
- 餐厅/时段/人数/饮食禁忌
