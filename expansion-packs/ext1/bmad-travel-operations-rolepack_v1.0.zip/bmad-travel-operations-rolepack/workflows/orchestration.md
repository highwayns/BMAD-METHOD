# Orchestration（编排操作手册）

## 节拍
Inquiry → Quote/Proposal → Contract/Deposit → Pre-Arrival（签证/预订/行程） → Arrival & Check-in → Daily Ops（接送/导览/餐饮/门票） → Incident & Changes → Departure → Post-Stay（反馈/对账）

## 常用命令
- `*agent reservations → *create-doc rooming-list`
- `*agent itinerary-designer → *create-doc itinerary-master`
- `*agent transportation-coordinator → *create-doc transfer-order`
- `*agent concierge → *create-doc concierge-log`
- `*agent platform-automation → *bundle`

## 触发器
- Deposit Received：合同签署并收订金
- D-1 18:00：锁定 daily-run-sheet 与交通排程
- Trip Closed：回款/反馈完成，进入对账与复盘
