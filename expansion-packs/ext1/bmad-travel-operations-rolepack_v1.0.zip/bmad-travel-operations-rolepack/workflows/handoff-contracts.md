# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Sales | Reservations | Deposit Received | docs/contract-deposit.md | docs/rooming-list.md | 房态/配额确认 |
| Reservations | Itinerary | Rooming List Final | docs/rooming-list.md | docs/itinerary-master.md | 资源可用/库存锁定 |
| Itinerary | Concierge | D-1 18:00 | docs/itinerary-master.md | docs/daily-run-sheet.md | 礼宾已回执 |
| Concierge | Transport/Guides | D-1 18:00 | docs/daily-run-sheet.md | docs/transfer-order.md / docs/guide-briefing.md | 司机/导游到位 |
| Ops | Finance | Trip Closed | data/reconciliation.csv | docs/invoice.md | 对账无差 |
