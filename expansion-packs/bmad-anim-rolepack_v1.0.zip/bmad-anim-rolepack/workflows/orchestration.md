# Orchestration（编排操作手册）

## 启动顺序（M0→M6）
M0 立项/简报 → M1 PRD/风格 → M2 分镜冻结 → M3 黄金镜头样板 → M4 量产 → M5 合成锁定 → M6 母版/分发。

## 关键操作
- 初始化：`*agent producer → *create-doc prd`
- 分片：`*agent producer → *shard-doc docs/prd.md prd`
- 出故事：`*agent director → *create-doc stories --count 10`
- 质控：`*agent qc → *create-doc qc/test-plan.md`
- 汇总打包：`*bundle`

## 触发器（示例）
- Layout 启动：`Boards Frozen`
- Animation 启动：`Layout Ready + Rig Ready`
- Comp 启动：`Lighting & FX Ready`
- Delivery 启动：`Comp Final + Color + Sound Approved`
