# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Producer | Director | PRD 冻结 | docs/prd.md | stories/* | Story Ready |
| Director | Storyboard | 风格/故事对齐 | stories/* | docs/boards/* | Boards Frozen |
| Storyboard | Layout | 分镜冻结 | docs/boards/* | shots/*/layout/* | Layout Ready |
| Modeling | Rigging | 模型定版 | assets/models/* | assets/rigs/* | Rig Ready |
| Layout+Rig | Animation | 布局+绑定就绪 | shots/*/layout/*, assets/rigs/* | shots/*/anim/* | Animation Approved |
| Animation+FX+Surf | Lighting | 动画通过+材质齐套 | shots/*/anim/*, assets/surfacing/* | lighting EXR/AOV | Lighting Ready |
| Lighting+FX | Compositing | 渲染层齐套 | exr/aov/* | comp final/* | Comp Final |
| Comp+Color+Sound | Editing | 三线齐套 | comp final/*, grade/*, audio/* | master/variants | Delivery Pass |
| All | QC | 迭代末 | 全部产物 | qa/reports/* | Signoff |
