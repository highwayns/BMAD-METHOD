# BMAD-Method 动画制作 RolePack
- 18 个角色独立文件（人格/任务/模板/编排/DoR/DoD）
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：共享输出模板（docs/shot/qc）
- checklists：质量门/反模式
- delivery：打包与合并
