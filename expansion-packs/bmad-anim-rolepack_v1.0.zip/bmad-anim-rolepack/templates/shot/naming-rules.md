# 命名规则
${SEQ}_${SHOT}_${DEPT}_vX.Y.Z_YYYYMMDD.ext
