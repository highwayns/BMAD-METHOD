# QC Report — Iteration ${ITER}
- 抽检范围：
- 缺陷列表：
- 回归记录：
- Signoff：
