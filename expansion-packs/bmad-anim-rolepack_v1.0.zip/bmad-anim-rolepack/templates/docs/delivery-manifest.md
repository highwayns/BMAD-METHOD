# Delivery Manifest
| File | Hash | Resolution | FPS | Codec/Bitrate | Duration |
|---|---|---|---|---|---|
