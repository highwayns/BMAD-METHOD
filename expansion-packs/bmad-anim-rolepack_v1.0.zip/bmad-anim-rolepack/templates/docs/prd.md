# PRD（动画项目）
- 项目：${PROJECT_NAME}
- 片型/时长/分发：${FORMAT}/${DURATION}/${CHANNELS}
- 目标受众：${AUDIENCE}
- 验收条款（AC）：镜头、技术、艺术、合规
- 里程碑：M0~M6
- 风险矩阵：${RISK_TABLE}
