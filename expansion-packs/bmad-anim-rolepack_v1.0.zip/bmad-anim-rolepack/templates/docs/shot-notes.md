# Shot Notes — ${SEQ}_${SHOT}
- 上游：Layout/Rig/Anim 输入
- 参数与版本：
- 已知问题与风险：
- 下游提示：
