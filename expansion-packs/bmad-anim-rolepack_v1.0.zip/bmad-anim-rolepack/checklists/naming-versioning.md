# 命名与版本规范
- 命名：${SEQ}_${SHOT}_${DEPT}_vX.Y.Z_YYYYMMDD.ext
- 版本：语义化（主.次.修订）
