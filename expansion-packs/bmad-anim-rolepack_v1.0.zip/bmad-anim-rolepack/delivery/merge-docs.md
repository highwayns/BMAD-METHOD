# 文档合并
- 分片（shard）→ 回填主文档
- 生成 merge report
