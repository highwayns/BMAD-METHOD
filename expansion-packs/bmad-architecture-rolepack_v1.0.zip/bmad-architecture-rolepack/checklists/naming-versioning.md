# 命名与版本
- `ARCH_${PROJECT}_${PHASE}_${DISC}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；重大变更需通知与回执
