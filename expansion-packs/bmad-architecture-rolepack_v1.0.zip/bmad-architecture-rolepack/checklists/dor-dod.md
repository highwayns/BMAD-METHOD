# DoR / DoD（按阶段）
- SD：需求/场地/法规明确；DoD：design-narrative + site-analysis + space-program 完成
- DD：多专业模型齐套；DoD：clash-report 合格，cost-plan 对齐
- CD：图纸/规范/清单闭环；DoD：drawing-index + spec-sections-index + tender-package-index 发布
- Permit：申报材料齐套；DoD：permitting-submission 回执
- CA/Closeout：RFI/变更/报验闭环；DoD：field-report + punchlist 清零，handover-checklist 完成
