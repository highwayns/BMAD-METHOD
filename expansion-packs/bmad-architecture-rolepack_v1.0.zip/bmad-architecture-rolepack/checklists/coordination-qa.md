# 协同 QA
- BEP/CDE 有效；会签纪要；问题闭环（issues.csv）
