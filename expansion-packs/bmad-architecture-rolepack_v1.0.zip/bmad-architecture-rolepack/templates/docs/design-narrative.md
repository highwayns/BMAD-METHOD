# Design Narrative（设计说明）
- 设计意图/策略/关键参数
