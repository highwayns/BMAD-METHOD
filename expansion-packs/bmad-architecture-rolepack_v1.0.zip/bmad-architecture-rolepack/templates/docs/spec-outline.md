# Spec Outline（规范纲要）
- 分部/范围/引用标准
