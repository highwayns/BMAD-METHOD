# Envelope Performance（围护）
- U值/SHGC/气密/热桥
