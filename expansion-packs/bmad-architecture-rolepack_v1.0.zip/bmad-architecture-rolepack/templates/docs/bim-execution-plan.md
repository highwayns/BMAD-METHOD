# BIM Execution Plan（BEP）
- 目标/流程/软件/标准
