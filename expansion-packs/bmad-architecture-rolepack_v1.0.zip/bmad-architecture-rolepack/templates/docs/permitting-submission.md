# Permitting Submission（报批材料）
- 清单/编号/盖章/回执
