# Accessibility Checklist（无障碍）
- 通行/卫生间/电梯/坡道
