# Design Options（方案选项）
- 方案A/B/C 与影响
