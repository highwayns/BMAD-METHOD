# Value Engineering（价值工程）
- 提案/影响/决策/状态
