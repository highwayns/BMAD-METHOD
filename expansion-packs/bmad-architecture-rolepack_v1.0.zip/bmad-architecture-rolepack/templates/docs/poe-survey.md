# Post-Occupancy Evaluation（POE）
- 满意度/舒适/改进
