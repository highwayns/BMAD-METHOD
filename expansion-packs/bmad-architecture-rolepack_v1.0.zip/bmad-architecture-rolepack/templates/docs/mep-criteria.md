# MEP Criteria（机电设计条件）
- 负荷/设备/管线/控制
