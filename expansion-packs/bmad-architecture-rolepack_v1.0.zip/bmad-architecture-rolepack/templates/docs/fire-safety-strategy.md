# Fire Safety Strategy（消防策略）
- 分区/防火/疏散/设施
