# Egress Calcs（疏散计算）
- 负荷/距离/宽度/时间
