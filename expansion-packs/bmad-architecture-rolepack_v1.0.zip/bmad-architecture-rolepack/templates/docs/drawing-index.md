# Drawing Index（图纸目录）
- 图号/名称/版本/责任
