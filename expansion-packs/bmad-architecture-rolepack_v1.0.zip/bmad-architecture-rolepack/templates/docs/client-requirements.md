# Client Requirements（业主需求）
- 功能/规模/标准/偏好
