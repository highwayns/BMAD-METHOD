# LOD Matrix（明细）
- 阶段/对象/深度/责任
