# Transmittal（传递单）
- 收件/内容/版本/签收
