# Decision Log（决策记录）
- 决策/依据/影响/责任
