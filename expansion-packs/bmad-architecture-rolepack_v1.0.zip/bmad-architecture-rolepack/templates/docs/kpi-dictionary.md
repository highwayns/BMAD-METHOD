# KPI Dictionary（指标）
- 冲突率/返工率/报批通过率/IFC 准时率
