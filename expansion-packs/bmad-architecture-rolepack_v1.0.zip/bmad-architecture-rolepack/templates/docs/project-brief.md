# Project Brief（项目任务书）
- PROJECT / SITE_ID / BLDG / 目标与范围
- 里程碑与预算/风险
