# CDE Protocol（共用数据环境）
- 权限/工作集/命名/流程
