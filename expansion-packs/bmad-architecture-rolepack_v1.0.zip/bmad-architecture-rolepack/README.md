# BMAD-Method｜建筑设计（Architecture Design & Delivery）RolePack
- 18 角色：人格/任务/模板/编排/DoR/DoD
- manifests：角色清单/能力矩阵/工作流索引
- workflows：编排手册/泳道图/交接契约
- templates：前期/方案/技术/报批/施工/招投标/现场/竣工模板 + CSV 数据
- checklists：质量门/模型与图纸 QA/合规/可持续/协同/变更/反模式
- delivery：打包与合并规则
