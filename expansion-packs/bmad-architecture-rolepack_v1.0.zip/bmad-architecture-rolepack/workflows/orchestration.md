# Orchestration（编排操作手册）

## 节拍
Feasibility → Concept（SD）→ Design Development（DD）→ Permitting → Construction Documents（CD）→ Tender/Bid → CA → Closeout（As-builts）→ POE

## 常用命令
- `*agent lead-architect → *create-doc design-narrative`
- `*agent bim-manager-and-digital-delivery → *create-doc clash-report`
- `*agent code-and-permitting-coordinator → *create-doc permitting-submission`
- `*agent construction-administration → *create-doc field-report`
- `*agent qa-qc-and-risk-manager → *create-doc drawing-qa`
- `*agent contracts-and-legal-manager → *create-doc transmittal`

## 触发器
- Design Freeze vX.Y：进入多专业协同
- Clash Resolved：提交 QA/QC 检查
- Permit Submitted：进入主管部门审查
- IFC Issued：施工开始
- Handover Complete：进入 POE
