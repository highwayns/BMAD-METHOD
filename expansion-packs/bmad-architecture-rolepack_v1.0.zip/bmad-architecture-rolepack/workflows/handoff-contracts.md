# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Lead Architect | BIM Manager | Design Freeze vX.Y | docs/drawing-index.md | docs/clash-report.md | 冲突≤阈值 |
| BIM Manager | QA/QC | Clash Resolved | docs/clash-report.md | docs/model-qa.md / docs/drawing-qa.md | 命名/坐标/LOD 合规 |
| Sustainability | Code/Permitting | DD Complete | docs/energy-model-summary.md | docs/permitting-submission.md | 申报清单通过 |
| CA | Contracts/Legal | Change Raised | docs/rfi-template.md | docs/change-order-log.md | 签署归档 |
