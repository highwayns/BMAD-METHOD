# 打包与归档规则
- 关键节点（Proposal/Protocol/IRB/Analysis/Deposit/Closeout）执行 *bundle：生成清单、校验哈希、版本快照
- 文档与数据分仓；审计日志同行
