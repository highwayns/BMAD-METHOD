# Orchestration（编排操作手册）

## 节拍
Concept/Aims → Funding Proposal → Award Setup → Protocol & SAP → 合规审批（IRB/IACUC/IBC）→ Pilot → Data Collection → QC/Analysis → Manuscript/Preprint → Data/Code Deposit → IP/Tech Transfer → Closeout

## 常用命令
- `*agent grants-and-funding-strategy → *create-doc grant-proposal`
- `*agent study-design-and-biostatistics → *create-doc sap-statistical-analysis-plan`
- `*agent ethics-irb-hrpp → *create-doc irb-application`
- `*agent data-management-and-fair-lead → *create-doc data-management-plan`
- `*agent publications-and-open-science → *create-doc manuscript-template`

## 触发器
- Aims Locked：进入 Proposal
- Protocol vX.Y：提交 IRB/IACUC/IBC
- Sample Manifest Locked：启动数据 QC
- Analysis Locked：进入 Manuscript
- Novelty Flag：触发发明披露
- Acceptance：存储库投递完成
