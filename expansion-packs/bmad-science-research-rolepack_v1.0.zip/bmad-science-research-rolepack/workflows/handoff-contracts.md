# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Design/Stats | IRB | Protocol vX.Y | docs/protocol-template.md + docs/sap-statistical-analysis-plan.md | docs/irb-application.md | IRB 受理 |
| Lab/LIMS | Data/FAIR | Sample Manifest Locked | data/sample-manifest.csv | docs/data-qc-checklist.md | QC 通过 |
| Data/FAIR | Publications | Analysis Locked | docs/repository-deposit-checklist.md | docs/data-sharing-statement.md | 可复现包可用 |
| Publications | IP/Tech Transfer | Novelty Flagged | docs/manuscript-template.md | docs/invention-disclosure.md | 披露归档 |
