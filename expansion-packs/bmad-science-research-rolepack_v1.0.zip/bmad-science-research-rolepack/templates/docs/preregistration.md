# Preregistration（预注册）
- 平台/条目/时间
