# Informed Consent（知情同意）
- 权利/撤回/联系方式
