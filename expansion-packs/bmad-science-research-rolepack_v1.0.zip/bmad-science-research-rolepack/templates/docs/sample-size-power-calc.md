# Sample Size & Power（样本量/效能）
- 假设/α/β
