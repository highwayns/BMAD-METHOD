# Deviation/NCR（偏差/不符合）
- 事件/处置/影响
