# Metadata Schema（元数据）
- 字段/词表/映射
