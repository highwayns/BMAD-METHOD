# Sample Manifest Guide（样本台账指南）
- 字段/校验
