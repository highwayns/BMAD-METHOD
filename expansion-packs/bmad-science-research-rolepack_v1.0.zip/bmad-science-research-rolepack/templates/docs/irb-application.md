# IRB Application（伦理申请）
- 风险/受益/保护/隐私
