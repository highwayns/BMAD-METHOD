# Repository Deposit（仓储投递）
- 元数据/许可/文件
