# Codebook（编码手册）
- 变量/取值/含义
