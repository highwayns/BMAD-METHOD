# KPI Dictionary（指标）
- 发表数/影响力/合规/KPI
