# De-identification Plan（去标识）
- 字段/方法/再识别风险
