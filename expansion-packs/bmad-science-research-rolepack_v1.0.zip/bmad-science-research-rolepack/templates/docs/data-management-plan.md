# Data Management Plan（DMP）
- 采集/存储/备份/共享
