# Data QC Checklist（数据质控）
- 完整性/一致性/范围/逻辑
