# Randomization Schedule（随机化）
- 序列/分配
