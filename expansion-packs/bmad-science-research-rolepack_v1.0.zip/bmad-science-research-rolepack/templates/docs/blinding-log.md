# Blinding Log（盲法）
- 角色/钥匙
