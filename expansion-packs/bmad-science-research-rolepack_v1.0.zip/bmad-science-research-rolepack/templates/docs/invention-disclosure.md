# Invention Disclosure（发明披露）
- 新颖性/所有权/计划
