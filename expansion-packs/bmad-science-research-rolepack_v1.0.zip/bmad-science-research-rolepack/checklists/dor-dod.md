# DoR / DoD（按阶段）
- Proposal：Aims/预算/DMP 就绪；DoD：grant-proposal 提交
- Protocol & SAP：变量与分析口径锁定；DoD：protocol & SAP 发布
- 合规审批：IRB/IACUC/IBC 审批通过；DoD：编号入库
- Data 收集/QC：校准/质控完成；DoD：qc-flags 全绿 + 审计日志
- Analysis/Manuscript：脚本/环境可复现；DoD：deposit-checklist + manuscript 完成
- Closeout：归档与 KPI 汇总；DoD：kpi.csv + lessons learned
