# 命名与版本
- `SR_${PROGRAM}_${PROJECT}_${WORKPACKAGE}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；破坏性变更需公告与回执
