# FAIR 数据
- Findable/Accessible/Interoperable/Reusable；元数据与持久标识
