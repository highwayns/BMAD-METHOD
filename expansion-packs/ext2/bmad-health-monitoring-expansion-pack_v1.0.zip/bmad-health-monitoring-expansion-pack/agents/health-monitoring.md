```yaml
agent:
  id: health-monitoring
  name: Health Monitoring Ops Agent
```