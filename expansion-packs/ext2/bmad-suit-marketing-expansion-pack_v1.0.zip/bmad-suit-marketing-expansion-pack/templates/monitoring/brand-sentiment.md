# Brand Sentiment Monitoring
- Social listening sources, alerts, escalation
