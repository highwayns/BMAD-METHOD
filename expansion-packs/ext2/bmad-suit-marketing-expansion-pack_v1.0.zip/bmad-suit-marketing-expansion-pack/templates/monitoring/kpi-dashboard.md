# KPI Dashboard Notes
- CAC, ROAS, LTV, Conv%, AOV, Return%, On-time fulfill
- Thresholds and weekly review cadence
