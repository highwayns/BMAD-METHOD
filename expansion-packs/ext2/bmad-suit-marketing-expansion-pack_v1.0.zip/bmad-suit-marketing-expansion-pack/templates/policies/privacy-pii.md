# Privacy & PII Policy
- Consent collection & retention
- Access control & audit
- Unsubscribe management
