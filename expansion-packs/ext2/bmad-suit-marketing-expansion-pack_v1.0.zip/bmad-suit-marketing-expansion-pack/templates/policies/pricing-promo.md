# Pricing & Promotion Policy
- Guardrails & approvals
- Lowest price rules
- Reconciliation & post-audit
