# Returns & Alterations Policy
- Eligibility & SLA
- Exceptions & goodwill
- Documentation
