# Valuation Policy (ASC 820 / IFRS 13)
- Methodologies and inputs
- Frequency, documentation, and audit trails
- Fair value memo requirements
