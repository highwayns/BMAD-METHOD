# Investment Policy Statement (IPS)
- Mandate, stages, sectors, check sizes, ownership targets
- Portfolio construction and reserves
- Decision authority and IC rules
