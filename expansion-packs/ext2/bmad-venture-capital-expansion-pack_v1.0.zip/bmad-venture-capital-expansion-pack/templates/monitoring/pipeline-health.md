# Pipeline Health
- Stage conversion, source effectiveness, theme coverage
