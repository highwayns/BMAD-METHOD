# KPI Dashboard Notes
- TVPI/DPI/IRR/PME, Hit/Loss, Time-to-close, Ownership/Reserves
- LP queries backlog, audit issues, compliance score
