# Orchestration
Fund Blueprint → Fundraising & LP Relations → Thesis→Dealflow→Screening → Diligence & IC → Legal & Closing
→ Portfolio Support & Governance → Valuation & Reporting → Cashflows & Waterfall → LP Relations & Audit → Lessons Learned
