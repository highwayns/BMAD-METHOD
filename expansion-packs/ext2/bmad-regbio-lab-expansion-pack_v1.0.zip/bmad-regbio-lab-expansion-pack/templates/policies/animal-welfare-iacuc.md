# Animal Welfare & IACUC Policy
- Protocol adherence and humane endpoints
- Monitoring logs and analgesia
- Training and competency records
