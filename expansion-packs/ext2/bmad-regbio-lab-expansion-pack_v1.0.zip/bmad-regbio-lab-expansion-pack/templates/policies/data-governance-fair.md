# Data Governance (FAIR)
- Metadata, versioning, and reproducibility
- Access & retention policies
- Backup and disaster recovery
