# Human Samples & Ethics Policy
- Consent, de-identification, and retention
- Access reviews and audit trails
- Data sharing and publication rules
