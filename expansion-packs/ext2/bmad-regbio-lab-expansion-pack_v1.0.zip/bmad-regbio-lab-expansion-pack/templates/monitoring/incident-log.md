# Incident Log Notes
- Spill/exposure/near-miss, root-cause, CAPA, dates and owners
