# KPI Dashboard Notes
- Contamination rate, Mycoplasma incidence, Release pass rate, Uptime, Repeatability index
- Thresholds and weekly review cadence
