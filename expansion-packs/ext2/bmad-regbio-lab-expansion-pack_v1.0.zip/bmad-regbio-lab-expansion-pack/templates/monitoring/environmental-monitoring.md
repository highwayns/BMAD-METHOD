# Environmental Monitoring Notes
- Temperature/CO2/particles/differential pressure logs with alert thresholds
