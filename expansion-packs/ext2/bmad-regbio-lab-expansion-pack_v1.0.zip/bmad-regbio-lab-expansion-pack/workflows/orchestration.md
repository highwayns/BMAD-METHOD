# Orchestration
Donor/Sample Intake → Cell Line/Organoid Establishment → Differentiation/Engineering → Assays & QC (CQAs)
→ Animal/Functional Validation → Data Governance & Analysis → Tech Transfer/Publication → Archival
