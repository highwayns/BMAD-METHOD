# Orchestration
Idea → Proposal/Grant → Ethics & COI → Protocols/SOPs → Sampling/Experiments → Data & QA → Analysis & Reproducibility
→ Publication & Sharing → IP/TT & Collaboration → Reporting & Audits → Lessons Learned
