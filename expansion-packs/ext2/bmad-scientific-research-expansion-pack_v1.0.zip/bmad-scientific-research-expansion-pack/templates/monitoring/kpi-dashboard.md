# KPI Dashboard Notes
- Grant win rate/burn, pubs & impact, open outputs
- QA pass rate, incident trends, compliance score
