# Authorship & Publication Policy
- ICMJE/CRediT
- Preprints, embargo, licenses
- Data/code/materials sharing checklist
