# Code & Data Sharing Policy
- Repositories, versions, DOIs
- Open source licensing & data licenses
- Security review prior to release
