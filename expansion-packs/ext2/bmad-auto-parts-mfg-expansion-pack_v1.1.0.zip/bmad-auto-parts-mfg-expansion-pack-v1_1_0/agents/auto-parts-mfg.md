```yaml
agent:
  id: auto-parts-mfg
  name: Auto Parts Manufacturing Agent
```