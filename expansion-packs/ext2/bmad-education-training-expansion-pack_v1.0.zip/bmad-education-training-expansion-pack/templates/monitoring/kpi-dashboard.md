# KPI Dashboard Notes
- Enrollment, retention, completion, placement
- Satisfaction (NPS/CSAT), quality defects, SLA
- Accessibility issues, privacy incidents, integrity flags
