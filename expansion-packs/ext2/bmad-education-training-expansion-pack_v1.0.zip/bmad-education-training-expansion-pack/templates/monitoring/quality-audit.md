# Content & Course QA Audit
- Broken links, readability, media accessibility
- Rubrics and blueprint consistency
- Versioning and release notes
