# Data Privacy & FERPA Policy
- Data dictionary & minimization
- Access controls, audits, retention
- DPIA and third-party processors
