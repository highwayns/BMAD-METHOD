# Content Licensing Policy
- Copyright, OER, Creative Commons
- Licensing terms and renewals
- Attribution and takedown process
