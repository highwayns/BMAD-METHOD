# Assessment Integrity Policy
- Blueprint & rubrics alignment
- Proctoring and plagiarism controls
- Gradebook governance and appeals
