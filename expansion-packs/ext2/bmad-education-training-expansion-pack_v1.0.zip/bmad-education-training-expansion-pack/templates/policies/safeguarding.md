# Safeguarding & Child Protection
- Staff vetting & training
- Incident reporting & response
- Duty of care and escalation
