# Orchestration
Appointment/Brief → Site & Surveys → Concept & SD → DD → CD → BIM Coordination → Permits (AHJ)
→ Tender & Procurement → Construction Administration → Handover & POE → Knowledge Capture
