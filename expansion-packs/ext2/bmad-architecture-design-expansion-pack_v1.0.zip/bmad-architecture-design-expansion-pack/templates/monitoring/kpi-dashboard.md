# KPI Dashboard Notes
- 里程碑准时率、RFI 响应天数、碰撞趋势、报批通过率、变更影响
- 阈值与周会例行
