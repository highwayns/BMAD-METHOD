# BIM Standards
- LOD/IFC/坐标/族/参数
- 命名/分类/视图/明细表
- 模型 QA 与交付包
