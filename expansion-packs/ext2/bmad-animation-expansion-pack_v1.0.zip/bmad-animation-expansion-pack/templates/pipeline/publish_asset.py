# placeholder: asset publish script hook
