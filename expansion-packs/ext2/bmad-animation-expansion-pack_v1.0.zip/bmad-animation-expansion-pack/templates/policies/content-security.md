# Content Security Policy
- Watermark all dailies
- Default deny on external share
- NDA tracking and approval workflow
