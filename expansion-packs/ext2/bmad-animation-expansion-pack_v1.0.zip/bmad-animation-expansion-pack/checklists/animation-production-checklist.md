<!-- Powered by BMAD™ Core -->

# Animation Production Checklist
用于交付前系统性验证动画制作的安全、合规、可靠性与实现质量（角色：制作管线/制片/技术）。

## 1. IP SECURITY & COMPLIANCE
- [ ] 权限最小化、访问审计；水印/加密；NDA/对外分享流程  

## 2. PIPELINE AS CODE
- [ ] 管线定义/脚本化（发布/构建/渲染/打包）；禁止手工漂移  

## 3. ASSET & SHOT CONTRACTS
- [ ] 数据契约、命名与目录规范、版本与依赖、交接契约  

## 4. PREPRODUCTION (SCRIPT/BOARDS/ANIMATIC)
- [ ] 标准、基线样例、审批流与留痕  

## 5. MODELING/RIGGING/LOOKDEV
- [ ] 建模/绑定/材质规范与校验；LOD 与兼容性  

## 6. LAYOUT/ANIMATION/FX
- [ ] 规则与物理参数、缓存策略、稳定性与回放一致性  

## 7. LIGHTING/RENDERING/COMPOSITING
- [ ] 渲染队列/配额/重试/检查点；合成模板与色彩一致性  

## 8. COLOR MANAGEMENT (ACES)
- [ ] 工作色彩空间、LUT/View、交付色彩规格  

## 9. AUDIO & EDITORIAL
- [ ] 声效/对白/音乐版权；剪辑/合版流程与追溯  

## 10. PERFORMANCE & RENDER FARM
- [ ] 队列与作业优化、缓存/代理、成本与时长基线  

## 11. MONITORING & DAILIES
- [ ] KPI/Dashboards；评审节拍、告警与覆盖率  

## 12. DOCUMENTATION VALIDATION
- [ ] 文档完整/一致/可用；强规则高亮；演进路线与 ADR  

## 13. CI/CD & PUBLISHING
- [ ] 资产/镜头发布流水线、签字/回滚/追踪  

## 14. BACKUP, DR & ARCHIVAL
- [ ] 备份/保留期/还原演练；项目归档策略  

## 15. COLLABORATION & HANDOFFS
- [ ] 跨部门接口、交接契约、状态板/可视化  

## 16. DELIVERY & QA
- [ ] 交付规格（分辨率/帧率/编解码/色彩）；QC 报告与签字  

---
### Prerequisites Verified
- [ ] 16 章已审阅；无未解决的高危；样片验证通过；回滚/还原演练通过；审批完备；与导演/制片/技术里程碑对齐
