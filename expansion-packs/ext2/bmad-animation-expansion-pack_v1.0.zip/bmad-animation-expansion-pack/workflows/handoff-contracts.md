# Handoff Contracts
| From | To | Trigger | Inputs | Outputs | Acceptance |
|---|---|---|---|---|---|
| Preproduction | Production Arch | Script/Boards Locked | brief.md | docs/animation-architecture.md | 阶段目标/规范一致 |
| Modeling | Rigging | Asset Ready | asset_registry.csv | rig_publish | 命名/拓扑合规 |
| Rigging/LookDev | Layout/Animation | Asset Publish | rig/lookdev publish | shot setup | 可用/稳定 |
| Animation/FX | Lighting | Shot Cache Ready | caches | lighting setup | 一致性/无缺帧 |
| Lighting | Compositing | Renders Ready | EXR/metadata | comp plates | 颜色/通道正确 |
| Compositing | Editorial | Shots Approved | review notes | edit bins | 版本/色彩一致 |
| Editorial | Delivery | Final Approval | edl/masters | delivery package | 规格/QC 通过 |
