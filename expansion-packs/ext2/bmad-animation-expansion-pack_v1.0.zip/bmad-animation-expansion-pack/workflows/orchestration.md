# Orchestration
Creative Brief → Script/Boards/Animatic → Production Architecture（Pipeline/IP/Contracts）
→ Assets (Model/Rig/LookDev) → Layout/Animation/FX → Lighting/Rendering → Compositing
→ Editorial & Audio → QA/QC → Delivery & Archival
