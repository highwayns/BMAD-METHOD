# KPI Dashboard Notes
- OTD, Gross margin, NPS, Complaint rate, Supplier SLA
- Thresholds and weekly review cadence
