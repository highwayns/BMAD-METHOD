# Refund & Cancellation Policy
- Cutoffs and fees
- Force majeure handling
- Documentation & approvals
