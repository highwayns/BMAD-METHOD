# Vendor SLA Policy
- Licenses and insurance
- Service levels & penalties
- Review and renewal cadence
