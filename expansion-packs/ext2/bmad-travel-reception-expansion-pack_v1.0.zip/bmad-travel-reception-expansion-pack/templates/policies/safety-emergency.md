# Safety & Emergency Policy
- Risk assessment and alerts
- 24/7 hotline & escalation tree
- Incident logging and postmortems
