# Orchestration
Client Intake → Job Profile & Terms → Sourcing → Screening/Assessments → Interviews → Offer & Pre-onboarding
→ Onboarding & Training → Dispatch & Scheduling → Payroll & Billing → KPI/Reporting → Renewal or Closure
