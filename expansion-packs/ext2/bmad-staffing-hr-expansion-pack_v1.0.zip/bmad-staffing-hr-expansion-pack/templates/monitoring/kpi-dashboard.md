# KPI Dashboard Notes
- Time-to-fill, Offer-accept rate, Quality-of-hire, Utilization, Margin
- SLA alerts and weekly review cadence
