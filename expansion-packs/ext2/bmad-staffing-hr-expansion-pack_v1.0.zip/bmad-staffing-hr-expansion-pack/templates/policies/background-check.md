# Background Check Policy
- Legal basis and scope
- Vendor due diligence and SLAs
- Candidate notification and dispute process
