# Privacy Policy
- Consent collection & retention policy
- Access control & audit
- Cross-border data transfer limitations
