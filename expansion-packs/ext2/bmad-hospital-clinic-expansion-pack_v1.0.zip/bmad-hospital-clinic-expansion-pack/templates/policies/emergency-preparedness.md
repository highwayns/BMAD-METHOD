# Emergency Preparedness
- Code Blue/Mass casualty drills
- Evacuation routes
- Communication plan
