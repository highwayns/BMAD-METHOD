# Infection Control Policy
- Isolation/PPE/hand hygiene
- Environmental cleaning & waste
- Surveillance and outbreak response
