# KPI Dashboard Notes
- LOS, Readmission, Wait-time, TAT, Med errors, HAI rate, Revenue/Cost
- Alert thresholds and weekly review cadence
