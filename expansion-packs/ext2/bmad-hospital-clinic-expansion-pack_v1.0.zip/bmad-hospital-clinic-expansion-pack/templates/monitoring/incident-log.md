# Incident Log Notes
- Record near-miss/adverse events, root-cause, corrective actions
