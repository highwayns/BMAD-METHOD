# Orchestration
Appointment → Triage → Consultation/Orders → Lab/Radiology → Pharmacy → Admission/OR (if needed)
→ Nursing & Care → Discharge Planning → Billing & Claims → Follow-up & Reporting
