# Orchestration
Venture Thesis → Customer Discovery → PMF → Product & SDLC → Cloud/DevOps → Security & Privacy → Data & Experiments
→ Growth & Marketing → Sales & Contracts → Customer Success → Fundraising & Board → Finance & Risk → Learn & Iterate
