# Board Governance Policy
- Cadence, pack structure, KPIs
- Approvals & minutes
- Conflicts and disclosures
