# Product Release Policy
- Branching, versioning, approvals
- Canary/feature flags/rollback
- Post-release monitoring and comms
