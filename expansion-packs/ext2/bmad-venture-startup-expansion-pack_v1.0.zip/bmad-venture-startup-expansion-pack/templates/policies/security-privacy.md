# Security & Privacy Policy
- Identity/least privilege/secrets
- Encryption and key management
- DPA/SCC/third-party risk, SOC2 controls
