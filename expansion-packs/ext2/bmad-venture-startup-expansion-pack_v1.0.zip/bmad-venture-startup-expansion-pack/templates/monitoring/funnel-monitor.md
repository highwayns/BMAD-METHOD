# Funnel Monitor
- Stage conversions, velocity, bottlenecks
