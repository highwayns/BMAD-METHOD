# KPI Dashboard Notes
- North star and core KPIs, OKR progress
- Growth funnel and CAC/Payback
- Reliability/SLO and security incidents
