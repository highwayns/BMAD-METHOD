# HR Analytics 报告
- 关键指标趋势（TTF/OAR/TPR/Utilization/DSO）：
- 风险与建议：
