# KPI 字典
- Time-to-Fill（TTF）
- Offer Acceptance Rate（OAR）
- Training Pass Rate（TPR）
- Utilization（稼动率）
- DSO（应收天数）
