# Orchestration（编排操作手册）

## 节拍（Recruit → Train → Dispatch → Payroll）
1. Lead & Account
2. JD Intake & Clarification
3. Sourcing & Screening
4. Interview & Offer
5. Onboarding
6. Training & Certification
7. Dispatch Assignment
8. Timesheet & Invoice
9. Payroll & Review

## 常用命令
- 初始化：`*agent orchestrator → *plan "P0-人才团队建盘"`
- JD 采集：`*agent client-partner → *create-doc jd-intake`
- 招聘推进：`*agent recruiter → *status`
- 打包归档：`*agent hris-platform → *bundle`

## 触发器
- Sourcing Start：JD DoR 通过
- Interview Scheduling：Screening Pass
- Onboarding Start：Offer 批准且合规通过
- Dispatch Start：Onboarding 完成
- Payroll Run：Timesheet 审批通过
