# 交接契约（Handoff Contracts）

| From | To | Trigger | Input Files | Output Files | Acceptance |
|---|---|---|---|---|---|
| Client Partner | TA Lead | JD DoR | docs/jd-intake.md | docs/candidate-profile.md | 字段齐全、需求澄清完毕 |
| TA Lead | Sourcer | TA Plan Ready | docs/candidate-profile.md | data/candidate-intake.csv | 候选人池数量与质量达标 |
| Recruiter | Interview Ops | Screening Pass | docs/screening-scorecard.md | data/interview-schedule.csv | 面试计划通知到位 |
| Recruiter | Compliance & Legal | Offer Draft | docs/offer-note.md | docs/compliance-register.md | 合规通过 |
| HR Ops | Dispatch Manager | Onboarding Complete | docs/onboarding-checklist.md | docs/assignment-order.md | 入场资料齐全 |
| Dispatch Manager | Payroll & Timesheet | Assignment Start | docs/assignment-order.md | data/timesheet.csv | 工时口径与政策一致 |
| Payroll & Timesheet | Finance | Timesheet Approved | data/timesheet.csv | data/invoice.csv | 对账一致 |
