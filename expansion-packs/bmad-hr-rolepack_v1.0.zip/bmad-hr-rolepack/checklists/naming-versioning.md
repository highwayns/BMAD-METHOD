# 命名与版本
- `{CLIENT}_{JDID}_{CANDID}_{DOC}_vX.Y_YYYYMMDD.ext`
- CSV UTF-8，无合并单元格；日期使用 ISO-8601
