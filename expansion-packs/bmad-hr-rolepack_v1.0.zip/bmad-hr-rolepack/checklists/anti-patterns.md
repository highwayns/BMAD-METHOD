# 反模式与对策
- JD 未澄清即大规模寻源 → 先执行 JD DoR 检查
- 面试反馈自由文本无结构 → 使用评分卡与编码
- Offer 口头承诺不留痕 → 使用 offer-note 与审批流
- Timesheet 口径不一致 → 统一 policy 并培训宣导
