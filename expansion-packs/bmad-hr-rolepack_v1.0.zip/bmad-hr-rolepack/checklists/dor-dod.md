# DoR / DoD（按阶段）
- JD DoR：字段齐全、薪资与地点明确、渠道/面试流程清楚、合规初检通过
- Screening DoD：评分卡完整、拒绝原因编码化、状态更新、留痕
- Offer DoR：背调完成、薪酬批复、合规审查
- Onboarding DoD：合同/账号/设备/隐私宣导齐全
- Dispatch DoD：Assignment 与 Policy 下发、客户确认
- Timesheet DoD：口径一致、审批记录完整
