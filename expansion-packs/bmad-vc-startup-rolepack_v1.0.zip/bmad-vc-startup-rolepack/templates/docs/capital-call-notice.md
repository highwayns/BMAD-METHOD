# Capital Call Notice（资金调用）
- 金额/用途/期限
