# NDA Template（保密协议范本）
- 定义/义务/期限/例外
