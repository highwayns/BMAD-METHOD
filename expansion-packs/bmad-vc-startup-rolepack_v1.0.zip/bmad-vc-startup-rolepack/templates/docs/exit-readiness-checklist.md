# Exit Readiness（退出准备）
- 财税/法务/运营/买方清单
