# ESOP Plan Outline（期权计划）
- 池子/授予/归属
