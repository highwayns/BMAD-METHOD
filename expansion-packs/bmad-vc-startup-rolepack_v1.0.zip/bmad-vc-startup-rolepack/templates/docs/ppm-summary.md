# PPM Summary（私募备忘录摘要）
- 结构/费用/条款/风险
