# Legal DD Checklist（法务尽调清单）
- 股权/合同/知识产权
