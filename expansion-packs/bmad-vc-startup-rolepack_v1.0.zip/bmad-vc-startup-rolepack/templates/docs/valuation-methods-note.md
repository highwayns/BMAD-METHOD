# Valuation Methods Note（估值方法说明）
- 方法/假设/敏感性
