# 命名与版本
- `VC_${FUND}_${VINTAGE}_${DEAL}_${ROUND}_${DOC}_vX.Y_YYYYMMDD`
- 版本语义化递增；重大变更需通知与回执
