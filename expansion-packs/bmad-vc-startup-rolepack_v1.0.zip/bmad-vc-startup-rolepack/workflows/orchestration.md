# Orchestration（编排操作手册）

## 节拍
Fundraising → Sourcing → Screening → Due Diligence → Investment Committee → Term Sheet → Legal & Closing → Onboarding（100D）→ Monitoring → Follow-on → Exit → Distribution

## 常用命令
- `*agent origination → *create-doc screening-onepager`
- `*agent research → *create-doc product-teardown`
- `*agent tech-and-product-due-diligence → *create-doc dd-checklist-tech`
- `*agent financial-modeling-and-valuation → *create-doc valuation-methods-note`
- `*agent transaction-term-sheet-and-execution → *create-doc term-sheet`
- `*agent portfolio-ops-and-value-creation → *create-doc 100-day-plan`
- `*agent investor-relations-and-reporting → *create-doc lp-quarterly-update`

## 触发器
- NDA Executed：开启数据室
- DD Pack Ready：进入 IC
- IC Approved：起草 TS
- Closing Complete：启动 100D
- Quarter Close：LP 季报
- SPA Signed：退出与分配
